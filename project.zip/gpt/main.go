package main

import (
	"database/sql"  ///работа с базой данных
	"encoding/json" ///читать и отправлять
	"fmt"           ///вывод текста в консоль
	"log"           ///для ошибок
	"net/http"      ///создавать апай запромсы

	_ "github.com/jackc/pgx/v5/stdlib" ///подключение к постгре
	"golang.org/x/crypto/bcrypt"       ///хэштрование пароли
)

var db *sql.DB ///подключение к датабейз

type Good struct { ///описание данных товара
	ID          int     `json:"id"`
	CategoryID  int     `json:"category_id"`
	Name        string  `json:"name"`
	Description string  `json:"description"`
	Price       float64 `json:"price"`
	Quantity    int     `json:"quantity"`
	InStock     bool    `json:"in_stock"`
}
type RegisterRequest struct { ///принятие данных от пользователя при регистрации
	Name     string `json:"name"`
	Email    string `json:"email"`
	Password string `json:"password"`
}
type LoginRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}
type AddToCartRequest struct {
	UserID   int `json:"user_id"`
	GoodID   int `json:"good_id"`
	Quantity int `json:"quantity"`
}
type CartItem struct {
	ID       int     `json:"id"`
	GoodID   int     `json:"good_id"`
	Name     string  `json:"name"`
	Price    float64 `json:"price"`
	Quantity int     `json:"quantity"`
	Total    float64 `json:"total"`
}

type UpdateUserRequest struct {
	UserID int    `json:"user_id"`
	Name   string `json:"name"`
}

func connectDB() { ///подключение го к дб
	var err error ///переменная для ошибок

	dsn := "postgres://postgres:wenfenpaitai65@localhost:5432/online_market?sslmode=disable"

	db, err = sql.Open("pgx", dsn)
	if err != nil {
		log.Fatal(err)
	}

	err = db.Ping()
	if err != nil {
		log.Fatal(err)
	}

	fmt.Println("Connected to PostgreSQL")
}

// /хандлер
func getGoods(w http.ResponseWriter, r *http.Request) {
	query := `
		SELECT id, category_id, name, description, price, quantity
		FROM goods
		WHERE 1=1
	`

	args := []any{}
	argID := 1

	categoryID := r.URL.Query().Get("category_id")
	if categoryID != "" {
		query += fmt.Sprintf(" AND category_id = $%d", argID)
		args = append(args, categoryID)
		argID++
	}

	inStock := r.URL.Query().Get("in_stock")
	if inStock == "true" {
		query += " AND quantity > 0"
	}

	sort := r.URL.Query().Get("sort")
	if sort == "price_asc" {
		query += " ORDER BY price ASC"
	} else if sort == "price_desc" {
		query += " ORDER BY price DESC"
	} else {
		query += " ORDER BY id"
	}

	rows, err := db.Query(query, args...)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var goods []Good

	for rows.Next() {
		var good Good

		err := rows.Scan(
			&good.ID,
			&good.CategoryID,
			&good.Name,
			&good.Description,
			&good.Price,
			&good.Quantity,
		)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		good.InStock = good.Quantity > 0
		goods = append(goods, good)
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(goods)
}
func main() {
	connectDB()

	http.HandleFunc("/goods", getGoods)
	http.HandleFunc("/register", register)
	http.HandleFunc("/login", login)
	http.HandleFunc("/cart/add", addToCart)
	http.HandleFunc("/cart", getCart)
	http.HandleFunc("/users/update", updateUser)
	http.HandleFunc("/users/delete", deleteUser)
	http.HandleFunc("/goods/delete", deleteGood)

	fmt.Println("Server started on http://localhost:4000")
	log.Fatal(http.ListenAndServe(":4000", nil))
}
func register(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Only POST method allowed", http.StatusMethodNotAllowed)
		return
	} ///сервер проверяет метод

	var req RegisterRequest

	err := json.NewDecoder(r.Body).Decode(&req)
	if err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	} //читает верность

	passwordHash, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	} //пароль в хаш

	_, err = db.Exec(`
		INSERT INTO users (name, email, password_hash)
		VALUES ($1, $2, $3)
	`, req.Name, req.Email, string(passwordHash))
	//сохранение юзера в таблицу
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{
		"message": "User registered successfully",
	})
}
func login(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Only POST method allowed", http.StatusMethodNotAllowed)
		return
	}

	var req LoginRequest

	err := json.NewDecoder(r.Body).Decode(&req)
	if err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}

	var userID int
	var passwordHash string

	err = db.QueryRow(` 
 
 `, req.Email).Scan(&userID, &passwordHash)

	if err != nil {
		http.Error(w, "Invalid email or password", http.StatusUnauthorized)
		return
	}

	err = bcrypt.CompareHashAndPassword([]byte(passwordHash), []byte(req.Password))
	if err != nil {
		http.Error(w, "Invalid email or password", http.StatusUnauthorized)
		return
	}
	//сравнение пароля с регистера
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]any{
		"message": "Login successful",
		"user_id": userID,
	})
}

func addToCart(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Only POST method allowed", http.StatusMethodNotAllowed)
		return
	}

	var req AddToCartRequest

	err := json.NewDecoder(r.Body).Decode(&req)
	if err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}

	var availableQuantity int

	err = db.QueryRow(`
		SELECT quantity
		FROM goods
		WHERE id = $1
	`, req.GoodID).Scan(&availableQuantity)
	//проверка количества
	if err != nil {
		http.Error(w, "Good not found", http.StatusNotFound)
		return
	}

	if availableQuantity < req.Quantity {
		http.Error(w, "Not enough goods in stock", http.StatusBadRequest)
		return
	}

	_, err = db.Exec(`
		INSERT INTO cart_items (user_id, good_id, quantity)
		VALUES ($1, $2, $3)
		ON CONFLICT (user_id, good_id)
		DO UPDATE SET quantity = cart_items.quantity + EXCLUDED.quantity
	`, req.UserID, req.GoodID, req.Quantity)
	//добавление товара в корзину
	if err != nil {
		http.Error(w, "Could not add item to cart", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{
		"message": "Item added to cart",
	})
}
func getCart(w http.ResponseWriter, r *http.Request) {
	userID := r.URL.Query().Get("user_id")
	//берет юзера
	if userID == "" {
		http.Error(w, "user_id is required", http.StatusBadRequest)
		return
	}

	rows, err := db.Query(`
		SELECT 
			cart_items.id,
			goods.id,
			goods.name,
			goods.price,
			cart_items.quantity
		FROM cart_items
		JOIN goods ON cart_items.good_id = goods.id
		WHERE cart_items.user_id = $1
	`, userID)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var cart []CartItem

	for rows.Next() {
		var item CartItem

		err := rows.Scan(
			&item.ID,
			&item.GoodID,
			&item.Name,
			&item.Price,
			&item.Quantity,
		)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		item.Total = item.Price * float64(item.Quantity)
		cart = append(cart, item)
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(cart)
}
func updateUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPut {
		http.Error(w, "Only PUT method allowed", http.StatusMethodNotAllowed)
		return
	}

	var req UpdateUserRequest

	err := json.NewDecoder(r.Body).Decode(&req)
	if err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}

	_, err = db.Exec(`
		UPDATE users
		SET name = $1
		WHERE id = $2
	`, req.Name, req.UserID)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{
		"message": "User name updated successfully",
	})
}
func deleteUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodDelete {
		http.Error(w, "Only DELETE method allowed", http.StatusMethodNotAllowed)
		return
	}

	userID := r.URL.Query().Get("user_id")

	if userID == "" {
		http.Error(w, "user_id is required", http.StatusBadRequest)
		return
	}

	_, err := db.Exec(`
		DELETE FROM users
		WHERE id = $1
	`, userID)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{
		"message": "User deleted successfully",
	})
}
func deleteGood(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodDelete {
		http.Error(w, "Only DELETE method allowed", http.StatusMethodNotAllowed)
		return
	}

	goodID := r.URL.Query().Get("good_id")

	if goodID == "" {
		http.Error(w, "good_id is required", http.StatusBadRequest)
		return
	}

	_, err := db.Exec(`
		DELETE FROM goods
		WHERE id = $1
	`, goodID)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{
		"message": "Good deleted successfully",
	})
}
